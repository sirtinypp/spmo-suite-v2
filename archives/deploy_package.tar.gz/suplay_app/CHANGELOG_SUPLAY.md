# Changelog - SUPLAY

All notable changes to the SUPLAY application (Virtual Store) will be documented in this file.

## [Unreleased]

### Fixed
- **Home Filters**: Applied `max-height: 200px` and scrollbars to Categories and Suppliers lists to prevent the sidebar from exceeding the viewport height. (Design Locked, minimal structural tweak).
