from django.contrib.auth import get_user_model

User = get_user_model()
user, created = User.objects.get_or_create(username='grootadmin')
user.set_password('xiarabasa12')
user.is_superuser = True
user.is_staff = True
user.save()

status = 'created' if created else 'updated'
print(f'grootadmin {status} successfully')
